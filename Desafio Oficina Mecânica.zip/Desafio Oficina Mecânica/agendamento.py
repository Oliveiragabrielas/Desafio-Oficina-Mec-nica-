"""Regras de agendamento de serviços."""
from datetime import datetime

from sistema_oficina.db import ErroNegocio, execute, query

STATUS = ("AGENDADO", "EM_ANDAMENTO", "CONCLUIDO", "CANCELADO")

SELECT = """
SELECT a.id, a.data_agendamento, a.status, a.observacao,
    s.id AS servico_id, s.descricao AS servico, s.valor,
    v.id AS veiculo_id, v.placa, v.marca, v.modelo, v.ano, v.cor,
    c.id AS cliente_id, c.nome AS cliente_nome, c.telefone, c.email, c.endereco
FROM agendamentos a
JOIN veiculos v ON v.id = a.veiculo_id
JOIN clientes c ON c.id = v.cliente_id
JOIN servicos s ON s.id = a.servico_id
"""


def _data(valor):
    if not isinstance(valor, str) or not valor.strip():
        raise ErroNegocio("Informe uma data e hora válidas.")
    try:
        return datetime.fromisoformat(valor.strip().replace("Z", ""))
    except ValueError:
        raise ErroNegocio("Data/hora inválida.") from None


def _id_positivo(valor, campo):
    try:
        id_ = int(valor)
    except (TypeError, ValueError):
        raise ErroNegocio(f"{campo} inválido.") from None
    if id_ <= 0:
        raise ErroNegocio(f"{campo} inválido.")
    return id_


def listar():
    return query(SELECT + " ORDER BY a.data_agendamento ASC, a.id ASC")


def listar_servicos():
    return query("SELECT id, descricao, valor FROM servicos ORDER BY descricao")


def obter(id_):
    resultados = query(SELECT + " WHERE a.id = %s", (id_,))
    if not resultados:
        raise ErroNegocio("Agendamento não encontrado.", 404)
    return resultados[0]


def cadastrar(d):
    data = _data(d.get("data_agendamento"))
    veiculo_id = _id_positivo(d.get("veiculo_id"), "Veículo")
    servico_id = _id_positivo(d.get("servico_id"), "Serviço")

    if not query("SELECT id FROM veiculos WHERE id = %s", (veiculo_id,)):
        raise ErroNegocio("Veículo não encontrado.", 404)
    if not query("SELECT id FROM servicos WHERE id = %s", (servico_id,)):
        raise ErroNegocio("Serviço não encontrado.", 404)

    id_, _ = execute(
        "INSERT INTO agendamentos "
        "(veiculo_id, servico_id, data_agendamento, observacao) "
        "VALUES (%s, %s, %s, %s)",
        (veiculo_id, servico_id, data, d.get("observacao")),
    )
    return obter(id_)


def editar(id_, d):
    """Atualiza a data obrigatória e, se enviados, status e observação."""
    atual = obter(id_)
    data = _data(d.get("data_agendamento"))
    status = d.get("status", atual["status"])
    if status not in STATUS:
        raise ErroNegocio("Status inválido.")

    execute(
        "UPDATE agendamentos "
        "SET data_agendamento = %s, status = %s, observacao = %s "
        "WHERE id = %s",
        (data, status, d.get("observacao", atual["observacao"]), id_),
    )
    return obter(id_)


def excluir(id_):
    obter(id_)
    execute("DELETE FROM agendamentos WHERE id = %s", (id_,))
