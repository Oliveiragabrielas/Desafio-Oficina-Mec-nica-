"""Entrada no sistema"""
import os
from datetime import timedelta
from flask import Flask
from rotas import bp

app = Flask(
    __name__,
    template_folder="sistema_oficina/templates",
    static_folder="sistema_oficina/static",
)
app.secret_key = os.getenv("SECRET_KEY", "troque-esta-chave-em-producao")
app.config.update(
    PERMANENT_SESSION_LIFETIME=timedelta(
        seconds=int(os.getenv("SESSION_EXPIRATION_SECONDS", "3600"))
    ),
    SESSION_REFRESH_EACH_REQUEST=False,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)
app.register_blueprint(bp)

if __name__ == "__main__":
    app.run(debug=True, port=5000)