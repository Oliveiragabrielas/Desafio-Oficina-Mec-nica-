"""Testar a conexão com o banco de daods testar_conexao.py"""
from sistema_oficina.db import testar_conexao


try:
    print("Conexão Ok:", testar_conexao())
except Exception as e:
    print("Falha na Conexão:", e)