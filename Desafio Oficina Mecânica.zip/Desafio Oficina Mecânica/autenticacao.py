"""Autenticação de usuários com bcrypt."""
import time
from functools import wraps

import bcrypt
from flask import jsonify, redirect, session

from sistema_oficina.db import ErroNegocio, query

EXPIRACAO_SEGUNDOS = 30 * 60


def gerar_hash(texto):
    return bcrypt.hashpw(
        texto.encode("utf-8"),
        bcrypt.gensalt(rounds=10),
    ).decode("utf-8")


def conferir(texto, hash_salvo):
    try:
        return bcrypt.checkpw(texto.encode("utf-8"), hash_salvo.encode("utf-8"))
    except (ValueError, TypeError):
        return False


def autenticar(login, senha):
    login, senha = (login or "").strip(), senha or ""
    if not login or not senha:
        raise ErroNegocio("Informe login e senha.")

    usuarios = query(
        "SELECT id, nome, senha_hash FROM usuarios WHERE login = %s",
        (login,),
    )
    if not usuarios or not conferir(senha, usuarios[0]["senha_hash"]):
        raise ErroNegocio("Login ou senha inválidos.", 401)
    return usuarios[0]


def iniciar_sessao(usuario):
    session.clear()
    session.permanent = True
    session.update(
        usuario_id=usuario["id"],
        nome=usuario["nome"],
        login_em=time.time(),
    )


def logado():
    if "usuario_id" not in session:
        return False
    if time.time() - session.get("login_em", 0) > EXPIRACAO_SEGUNDOS:
        session.clear()
        return False
    return True


def api_protegida(f):
    @wraps(f)
    def interno(*args, **kwargs):
        if not logado():
            return jsonify(erro="Sessão expirada. Faça login novamente."), 401
        return f(*args, **kwargs)

    return interno


def pagina_protegida(f):
    @wraps(f)
    def interno(*args, **kwargs):
        if not logado():
            return redirect("/login")
        return f(*args, **kwargs)

    return interno
